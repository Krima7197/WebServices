<?php
$cn = new mysqli("localhost","root","","MyDBEmployee");
//$id=$_REQUEST["id"];
$name=$_REQUEST["name"];
$address=$_REQUEST["address"];
//$mon=$_REQUEST["mon"];
$q = mysqli_query($cn,"select * from employee where name = '$name' and address = '$address'");
if (mysqli_num_rows($q)==0) 
{	
	$row = array();
	print_r(json_encode($row));
}
else
{
	while ($row=mysqli_fetch_assoc($q))
    {
		$pp[]=$row;
	}
	echo json_encode($pp);
}
?>